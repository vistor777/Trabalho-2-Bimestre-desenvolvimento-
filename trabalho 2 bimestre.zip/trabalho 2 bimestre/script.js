function VerificarTriangulo() {

    var x = parseFloat(document.getElementById('x').value);
    var y = parseFloat(document.getElementById('y').value);
    var z = parseFloat(document.getElementById('z').value);

    var resultado = document.getElementById('resultado');

    if (isNaN(x) || isNaN(y) || isNaN(z) || x <= 0 || y <=0 || z <=0) {
        resultado.textContent = "insira valores maiores que 0";
        return;
    }

    if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z) {
            resultado.textContent = "Triangulo equilatero";
        } else if (x === y || y === z || x ===z){
            resultado.textContent = "Triangulo isosceles";
        } else {
            resultado.textContent = "Triangulo escaleno";
        }
    } else {
        resultado.textContent = "Os numeros nao formam um triangulo";
    }

}


function calcular() {
    var peso = parseFloat(document.getElementById('peso').value);
    var altura = parseFloat(document.getElementById('altura').value);
    var resultadoIMC = document.getElementById('resultadoIMC');

    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
        resultadoIMC.textContent = "Digite valores validos";
        return;

    }


    var imc = peso / (altura * altura);
    var classificacao = "";

    if (imc < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (imc < 25) {
        classificacao = "Peso normal";
    } else if (imc < 30) {
        classificacao = "Sobrepeso";
    } else if (imc < 35) {
        classificacao = "Obesidade grau 1";
    } else if (imc < 40) {
        classificacao = "Obesidade grau 2";
    } else {
        classificacao = "Obesidade grau 3";
    }

    resultadoIMC.textContent = "Seu IMC e " + imc.toFixed(2) + " - " + classificacao;

}

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("btcalcular").addEventListener("click", calcularImposto);
});

function calcularImposto() {
    const ano = parseInt(document.getElementById("ano").value);
    const valor = parseFloat(document.getElementById("valor").value);

    if (isNaN(ano) || isNaN(valor) || ano < 1900 || ano > 2099 || valor <= 0) {
        alert("Digite numeros validos");
        return;
    }

    let taxa;
    let imposto;

    if (ano < 1990) {
        taxa = 1;
        imposto = valor * 0.01;
    } else {
        taxa = 1.5;
        imposto = valor * 0.015;
    }

    const valorFormatado = valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
    const impostoFormatado = imposto.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });

    const resultadoI = document.getElementById("resultadoIMPOSTO");
    resultadoI.innerHTML = `
        <p>Veículo fabricado em: <strong>${ano}</strong></p>
        <p>Valor de tabela: <strong>${valorFormatado}</strong></p>
        <p>Taxa: <strong>${taxa}%</strong></p>
        <p>Imposto a pagar: <strong>${impostoFormatado}</strong></p>
    `;
}

function calcularSalario(){
    const salario = parseFloat(document.getElementById("salario").value);
    const cargo = parseInt(document.getElementById("cargo").value);
    const resultadoSALARIO = document.getElementById("resultadoSALARIO");

    if(isNaN(salario) || salario <= 0 || isNaN(cargo)) {
        resultadoSALARIO.innerHTML = "Digite numeros validos";
        return;
    }

    let percentual
    let nomecargo;

    switch (cargo) {
        case 101:
            nomecargo = "Gerente";
            percentual = 10;
            break;

            case 102:
                nomecargo = "Engenheiro";
                percentual = 20;
                break;

                case 103:
                    nomecargo = "Tecnico";
                    percentual = 30;
                    break; 
                    default:
                    nomecargo = "Outro";
                    percentual = 40;
                    break;

    }

    const aumento = salario * (percentual / 100);
    const novosalario = salario + aumento;

    resultadoSALARIO.innerHTML = `
    <p><strong>Cargo:</strong> ${nomecargo}</p>
    <p><strong>Salário antigo:</strong> R$ ${salario.toFixed(2)}</p>
    <p><strong>Percentual de aumento:</strong> ${percentual}%</p>
    <p><strong>Valor do aumento:</strong> R$ ${aumento.toFixed(2)}</p>
    <p><strong>Novo salário:</strong> R$ ${novosalario.toFixed(2)}</p>
    `;
}

function calcularcredito() {
    const saldo = parseFloat(document.getElementById("saldo").value);
    const resultadoCREDITO = document.getElementById("resultadoCREDITO");

    if(isNaN(saldo) || saldo < 0) {
        resultadoCREDITO.innerHTML = "Digite um numero valido";
        return;

    }

    let percentual = 0;
     if (saldo > 600) {
        percentual = 40;
     } else if (saldo > 400) {
        percentual = 30;
     } else if (saldo > 200){
        percentual = 20;
     }

     const credito = saldo * (percentual / 100)

     resultadoCREDITO.innerHTML = `
        <p><strong>Saldo médio:</strong> R$ ${saldo.toFixed(2)}</p>
        <p><strong>Crédito concedido:</strong> R$ ${credito.toFixed(2)} (${percentual}%)</p>
    `;
}


function calcularLANCHES() {
    var codigos = document.getElementsByClassName("codigo");
    var quantidades = document.getElementsByClassName("quantidade");
    var res = document.getElementById("resposta");

    var total = 0;
    var mensagem = "";

    for (var i = 0; i < codigos.length; i++) {
        var cod = parseInt(codigos[i].value);
        var qtd = parseInt(quantidades[i].value);

        if (isNaN(cod) || isNaN(qtd) || qtd <= 0) {
            continue;
        }

        var preco = 0;
        var item = "";

        if (cod == 1) {
            preco = 11;
            item = "Cachorro Quente";
        } else if (cod == 2) {
            preco = 8.5;
            item = "Bauru";
        } else if (cod == 3) {
            preco = 8;
            item = "Misto Quente";
        } else if (cod == 4) {
            preco = 9;
            item = "Hamburguer";
        } else if (cod == 5) {
            preco = 10;
            item = "Cheeseburger";
        } else if (cod == 6) {
            preco = 4.5;
            item = "Refrigerante";
        } else {
            mensagem += `<p>Código ${cod} inválido.</p>`;
            continue;
        }

        var subtotal = preco * qtd;
        total += subtotal;

        mensagem += `<p>${qtd}x ${item} - R$ ${subtotal.toFixed(2)}</p>`;
    }

    if (total == 0) {
        res.innerHTML = "Nenhum item válido foi inserido.";
    } else {
        res.innerHTML = mensagem + `<p><strong>Total a pagar: R$ ${total.toFixed(2)}</strong></p>`;
    }
}


function calcularVENDA() {
    var preco = parseFloat(document.getElementById("preco").value)
    var forma = document.getElementById("forma").value
    var res = document.getElementById("saida")

    if (isNaN(preco) || preco <= 0 || forma == "") {
        res.innerHTML = "Preencha os dados de forma correta"
        return;
    }

    var total = 0
    var texto = ""

    if (forma == "a") {
        total = preco - (preco * 0.10)
        texto = "Pagamento a vista em dinheiro/cheque desconto de 10%"
    } else if (forma == "b") {
        total = preco - (preco * 0.15)
        texto = "Pagamento a vista no cartão desconto de 15%"
    } else if (forma == "c") {
        total = preco
        texto = "Pagamento em 2x sem juros preço normal"
    } else if (forma == "d") {
        total = preco + (preco * 0.10)
        texto = "Pagamento em 2x com juros de 10%"
    } else {
        res.innerHTML = "Código de forma de pagamento inválido"
        return;
    }

    res.innerHTML = "<p>" + texto + "</p>" +
                    "<p>Valor final: R$ " + total.toFixed(2) + "</p>"
}


function SalarioPROFESSORES() {
    var nivel = parseInt(document.getElementById("nivel").value);
    var horas = parseFloat(document.getElementById("horas").value);
    var resSalarioProf = document.getElementById("resSalarioProf");

    if (isNaN(nivel) || isNaN(horas) || horas <= 0) {
        resSalarioProf.innerHTML = "Digite valores válidos";
        return;
    }

    var valorHora = 0;

    if (nivel === 1) {
        valorHora = 12;
    } else if (nivel === 2) {
        valorHora = 17;
    } else if (nivel === 3) {
        valorHora = 25;
    } else {
        resSalarioProf.innerHTML = "Nível inválido, use 1, 2 ou 3";
        return;
    }

    var salarioPROF = valorHora * horas * 4.5;

    resSalarioProf.innerHTML = "O salário do professor é R$ " + salarioPROF.toFixed(2);
}
